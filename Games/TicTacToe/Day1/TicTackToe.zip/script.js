console.log("script connected");
let currentPlayer = "X";
const c1 = document.getElementById("c1");
console.log(c1);
c1.addEventListener("click", function () {
    console.log("Cell 1 clicked")
    if (c1.innerText !== "") {
        return;
    }
    c1.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"

    } else {
        currentPlayer = "X"
    }
});
const c2 = document.getElementById("c2");
console.log(c2);
c2.addEventListener("click", function () {
    console.log("Cell 2 clicked")
    if (c2.innerText !== "") {
        return;
    }
    c2.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"

    } else {
        currentPlayer = "X"
    }
});
const c3 = document.getElementById("c3");
c3.addEventListener("click", function () {
    if (c3.innerText !== "") {
        return;
    }
    c3.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"
    } else {
        currentPlayer = "X"
    }
})
const c4 = document.getElementById("c4");
c4.addEventListener("click", function () {
    if (c4.innerText !== "") {
        return
    }
    c4.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"
    } else {
        currentPlayer = "X"
    }
})
const c5 = document.getElementById("c5");
c5.addEventListener("click", function () {
    if (c5.innerText !== "") {
        return
    }
    c5.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"
    } else {
        currentPlayer = "X"
    }
})
const c6 = document.getElementById("c6");
c6.addEventListener("click", function () {
    if (c6.innerText !== "") {
        return;
    }
    c6.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"
    } else {
        currentPlayer = "X"
    }
})
const c7 = document.getElementById("c7");
console.log(c7);
c7.addEventListener("click", function () {
    console.log("Cell 7 clicked")
    if (c7.innerText !== "") {
        return;
    }
    c7.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"

    } else {
        currentPlayer = "X"
    }
});
const c8 = document.getElementById("c8");
console.log(c8);
c8.addEventListener("click", function () {
    console.log("Cell 8 clicked")
    if (c8.innerText !== "") {
        return;
    }
    c8.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"

    } else {
        currentPlayer = "X"
    }
});
const c9 = document.getElementById("c9");
console.log(c9);
c9.addEventListener("click", function () {
    console.log("Cell 9 clicked")
    if (c9.innerText !== "") {
        return;
    }
    c9.innerText = currentPlayer;
    if (currentPlayer === "X") {
        currentPlayer = "O"

    } else {
        currentPlayer = "X"
    }
});